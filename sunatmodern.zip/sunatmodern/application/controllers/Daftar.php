<?php

class Daftar extends CI_Controller {
    public function index() {
        $this->load->view('daftar');
    }
}