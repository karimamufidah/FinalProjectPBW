<?php

class Kontak extends CI_Controller {
    public function index() {
        $this->load->view('kontak');
    }
}