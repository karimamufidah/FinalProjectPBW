<?php

class Layanan extends CI_Controller {
    public function index() {
        $this->load->view('layanan');
    }
}