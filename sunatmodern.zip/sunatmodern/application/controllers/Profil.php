<?php

class Profil extends CI_Controller {
    public function index() {
        $this->load->view('profil');
    }
}